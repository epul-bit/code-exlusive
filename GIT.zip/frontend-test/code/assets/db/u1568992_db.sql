-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 24, 2021 at 11:41 AM
-- Server version: 10.3.32-MariaDB-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u1568992_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `no` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`no`, `username`, `password`) VALUES
(1, 'admin', '87a96f8ce1158d624a45ef64d8bbff1a');

-- --------------------------------------------------------

--
-- Table structure for table `tb_belajar`
--

CREATE TABLE `tb_belajar` (
  `no` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `slide1` int(11) NOT NULL,
  `slide2` int(11) NOT NULL,
  `slide3` int(11) NOT NULL,
  `slide4` int(11) NOT NULL,
  `slide5` int(11) NOT NULL,
  `selesai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_belajar`
--

INSERT INTO `tb_belajar` (`no`, `id_kelas`, `email`, `slide1`, `slide2`, `slide3`, `slide4`, `slide5`, `selesai`) VALUES
(19, 1, 'ramdhan.rpe@bsi.ac.id', 1, 1, 1, 0, 0, 0),
(20, 1, 'ramdhan.rpe@gmail.com', 1, 1, 0, 0, 0, 0),
(21, 1, 'yogas0107@gmail.com', 1, 1, 0, 0, 0, 0),
(22, 1, 'desipuspita00@gmail.com', 1, 1, 0, 0, 0, 0),
(23, 1, 'ramdhandhan16@gmail.com', 1, 1, 0, 0, 0, 0),
(24, 1, 'eckytama7@gmail.com', 1, 1, 0, 0, 0, 0),
(25, 1, 'isnaenikustiningsih21@gmail.com', 1, 0, 0, 0, 0, 0),
(26, 1, 'zeanidahlan8@gmail.com', 1, 1, 0, 0, 0, 0),
(27, 1, 'ridwanalfatih@digitalkode.com', 1, 1, 0, 0, 0, 0),
(28, 1, 'ridanutria@gmail.com', 1, 0, 0, 0, 0, 0),
(29, 1, 'oviputrilesmana@gmail.com', 1, 1, 0, 0, 0, 0),
(30, 1, 'Melishafauziah196@gmail.com', 1, 1, 0, 0, 0, 0),
(31, 1, 'Hendrikddmotto@gmail.com', 1, 1, 0, 0, 0, 0),
(32, 1, 'amaliari2305@gmail.com', 1, 1, 0, 0, 0, 0),
(33, 1, 'encep.sunandar@gmail.com', 1, 0, 0, 0, 0, 0),
(34, 1, 'meilanitam12@gmail.com', 1, 1, 0, 0, 0, 0),
(35, 1, 'ggmharis@gmail.com', 1, 1, 0, 0, 0, 0),
(36, 1, 'adellafatinnia2016@gmail.com', 1, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id_kelas` int(11) NOT NULL,
  `kelas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kelas`
--

INSERT INTO `tb_kelas` (`id_kelas`, `kelas`) VALUES
(1, 'Website Slip Gaji');

-- --------------------------------------------------------

--
-- Table structure for table `tb_member`
--

CREATE TABLE `tb_member` (
  `id_member` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jam` varchar(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `tgl_lahir` varchar(30) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_member`
--

INSERT INTO `tb_member` (`id_member`, `tgl`, `jam`, `nama`, `telp`, `tgl_lahir`, `kategori`, `alamat`, `email`, `password`) VALUES
(12, '2021-10-12', '10:36', 'Ramdhan Saepul Rohman', '085280268295', '23/11/1993', 'Dosen', 'Perum Alam Layung Indah Blok O12 Cisande Sukabumi', 'ramdhan.rpe@bsi.ac.id', 'basararamadan'),
(28, '2021-10-21', '21:15', 'Rida Nutria Lestari', '085659471364', '03-02-1999', 'Mahasiswa', 'Jl. Gudang, Sagaranten, Kab. Sukabumi', 'ridanutria@gmail.com', 'Dontorewok32'),
(29, '2021-10-21', '21:15', 'maya ulfa fauziah', '083818227231', '23/09/1996', 'Mahasiswa', 'Jl.Cemerlang RT04/RW02  Kel.Sukakarya Kec.Warudoyong Kota Sukabumi', 'mayaulfa2309@gmail.com', 'sukabumi'),
(30, '2021-10-21', '21:19', 'Muhammad Yoga Saputra', '081316008716', '19/06/1994', 'Mahasiswa', 'Jl. Garuda No. 41 Sukabumi', 'yogas0107@gmail.com', 'Islami07'),
(31, '2021-10-21', '21:22', 'Anisa Fajria', '085722046599', '01/08/1998', 'Mahasiswa', 'Jl Subangjaya rt/rw 05/04 kel subangjaya kec cikole', 'Anisafaj3@gmail.com', 'Anisafaj@09'),
(32, '2021-10-21', '21:22', 'Neng Sella Zakiatun Nufus', '08975905773', '15-03-1997', 'Mahasiswa', 'Kp.pabuaran RT/RW 01/01desa Ciheulang tonggoh kecamatan Cibadak kab Sukabumi', 'nengsellazakiatunnufus@gmail.com', 'btssaveme'),
(33, '2021-10-21', '22:11', 'R Rama Gumelar', '085212346369', '23/05/1998', 'Mahasiswa', 'KP. SUNDAWENANG, RT/RW 031/013, Kel/Desa SUNDAWENANG, Kecamatan PARU NG KUDA', 'rizkirama2@gmail.com', '23mei198'),
(34, '2021-10-22', '14:48', 'Desi Puspita Sari', '085659669099', '04/06/1997', 'Mahasiswa', 'Kp. Kaum Kidul rt 11 rw 04 Desa Cisaat', 'desipuspita00@gmail.com', 'Sukabumi97'),
(36, '2021-10-22', '20:30', 'novia anggraeni', '081287964115', '20/11/1993', 'Mahasiswa', 'Jl siliwangi Gg h marjuki, kebonjati-cikole, kota sukabumi.', 'oviputrilesmana@gmail.com', 'sukabumi93'),
(37, '2021-10-22', '20:40', 'Ricky Nurdiansyah', '089657763867', '30/03/1989', 'Mahasiswa', 'Kp. Ubrug RT 01 RW 04, Ds. Ubrug, Kec. Warungkiara, Kab. Sukabumi', 'eckytama7@gmail.com', '22Desember'),
(38, '2021-10-22', '21:00', 'Silvia Ananda', '085721210161', '02/05/2000', 'Mahasiswa', 'Jl.Sudajaya Hilir', 'Silviaananda47@gmail.com', 'sian12180776'),
(39, '2021-10-23', '04:49', 'Isnaeni Kustiningsih', '088221156052', '06/01/1999', 'Mahasiswa', 'Cikidang rt 3 rw 2 Kecamatan Cilongok', 'isnaenikustiningsih21@gmail.com', 'Isnaeni115'),
(40, '2021-10-25', '08:52', 'Anisa Ibrahim', '089691478201', '05/12/1996', 'Mahasiswa', 'Kp. Rawabumin RT 02 RW 02 Desa Lembursawah Kecamatan Sukabumi Kabupaten Sukabumi', 'anisaibrahim96@gmail.com', 'Bapakumi5'),
(41, '2021-10-27', '05:08', 'Zeni Dahlan', '085781198382', '1996-08-30', 'Mahasiswa', 'Jl. Selabintana Sukabumi', 'zeanidahlan8@gmail.com', '19211242@'),
(42, '2021-10-27', '16:36', 'Moh. Ridwan Saputra', '085722991389', '21/10/1999', 'Mahasiswa', 'Kp.Talang Rt.10/03 Desa. Palsarigirang Kec.Klapanunggal Kab. Sukabumi Jawa Barat', 'ridwanalfatih@digitalkode.com', '123456'),
(43, '2021-10-30', '07:44', 'Amalia Rizki Yudistira', '08886957230', '23/05/1998', 'Mahasiswa', 'Gumuk indah, Ngestiharjo, Kasihan, Bantul', 'amaliari2305@gmail.com', 'amalia123'),
(44, '2021-10-30', '10:59', 'MELISHA FAUZIAH MAULAN', '085866357745', '03/03/1998', 'Mahasiswa', 'YOGYAKARTA', 'Melishafauziah196@gmail.com', 'Maulan041'),
(45, '2021-10-30', '11:48', 'Hendrik', '081282128212', '13/06/90', 'Mahasiswa', 'Jl. Pabuaran No.71', 'Hendrikddmotto@gmail.com', 'Marzia123'),
(46, '2021-10-31', '18:39', 'abdul majid abdalah', '085782189711', '27-05-1997', 'Mahasiswa', 'kp. ciherang desa margaluyu kecamatan sagaranten kabupaten sukabumi', 'abdulmajidabdalah27@gmail.com', 'Ciherang27'),
(47, '2021-10-31', '18:38', 'Encep Sunandar', '085659520510', '08/08/1989', 'Mahasiswa', 'Perumahan Puri Asri Limbangan Warung kondang kabupaten cianjur', 'encep.sunandar@gmail.com', 'Password'),
(48, '2021-10-31', '20:20', 'Meilani Taman Surya Thomas', '085871324402', '12/03/93', 'Siswa', 'Jl. Pajajaran 1 no 100 cisaat rambay', 'meilanitam12@gmail.com', 'Michell3'),
(49, '2021-11-11', '08:32', 'Taufiqurahman', '085793906000', '16/11/1990', 'Umum', 'Kp Baru Legok Bitung RT 04/12 Limusnunggal, Cibeureum Kota Sukabumi', 'taufiqurahman.fh@gmail.com', '123456.vk'),
(50, '2021-11-11', '13:21', 'Diyanto', '081535351412', '31/03/1993', 'Umum', 'Perum Assyifa blok E2 no 6 RT 06 RW 8 karangteng', 'dianto.brew09@gmail.com', 'b123w'),
(51, '2021-11-11', '17:23', 'HARIS SUPRIATNA', '083820878157', '11/08/1983', 'Umum', 'JL.HEGARMANAH CIKENDI NO.6\'166a, RT/RW 005 / 003, Kel/Desa HEGARMANAH, Kecamatan CIDADAP', 'ggmharis@gmail.com', 'semuataksama'),
(53, '2021-12-13', '15:34', 'Adella', '082158796319', '29/01/00', 'Mahasiswa', 'jl.swadaya 2', 'adellafatinnia2016@gmail.com', 'adel2901'),
(54, '2021-12-15', '22:39', 'Mike Arnold\r\n', 'Mike Arnold\r\n', 'Local SEO for more business', 'Guru', 'Hello \r\n \r\nWe will improve your Local Ranks organically and safely, using only whitehat methods, while providing Google maps and website offsite work at the same time. \r\n \r\nPlease check our pricelist here, we offer Local SEO at cheap rates. \r\nhttps://speed-seo.net/product/local-seo-package/ \r\n \r\nNEW: \r\nhttps://www.speed-seo.net/product/zip-codes-gmaps-citations/ \r\n \r\nregards \r\nMike Arnold\r\n \r\nSpeed SEO Digital Agency', 'no-replycog@gmail.com', '5q!p89dgUqP'),
(55, '2021-12-23', '02:26', 'JAMES COOK', 'JAMES COOK', 'Loan @ 3%', 'Umum', 'Dear sir/ma \r\nWe are a finance and investment company offering loans at 3% interest rate. We will be happy to make a loan available to your organisation for your project. Our terms and conditions will apply. Our term sheet/loan agreement will be sent to you for review, when we hear from you. Please reply to this email ONLY cookj5939@gmail.com \r\n \r\nRegards. \r\nJames Cook \r\nChairman & CEO Euro Finance & Commercial Ltd', 'james_cook78@yahoo.com', 'kg8d25Ot@xR');

-- --------------------------------------------------------

--
-- Table structure for table `tb_order`
--

CREATE TABLE `tb_order` (
  `id_order` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_order`
--

INSERT INTO `tb_order` (`id_order`, `email`, `id_kelas`, `status`) VALUES
(7, 'ramdhan.rpe@bsi.ac.id ', 1, 'Diterima'),
(11, 'ramdhan.rpe@gmail.com ', 1, 'Diterima'),
(12, 'ridanutria@gmail.com ', 1, 'Diterima'),
(13, 'mayaulfa2309@gmail.com ', 1, 'Diterima'),
(14, 'yogas0107@gmail.com ', 1, 'Diterima'),
(15, 'nengsellazakiatunnufus@gmail.com ', 1, 'Diterima'),
(16, 'desipuspita00@gmail.com ', 1, 'Diterima'),
(17, 'ramdhandhan16@gmail.com ', 1, 'Diterima'),
(18, 'eckytama7@gmail.com ', 1, 'Diterima'),
(19, 'silviaananda47@gmail.com ', 1, 'Diterima'),
(20, 'isnaenikustiningsih21@gmail.com ', 1, 'Diterima'),
(21, 'zeanidahlan8@gmail.com ', 1, 'Diterima'),
(22, 'ridwanalfatih@digitalkode.com ', 1, 'Diterima'),
(23, 'oviputrilesmana@gmail.com ', 1, 'Diterima'),
(24, 'amaliari2305@gmail.com ', 1, 'Diterima'),
(25, 'Melishafauziah196@gmail.com ', 1, 'Diterima'),
(26, 'Hendrikddmotto@gmail.com ', 1, 'Diterima'),
(27, 'anisaibrahim96@gmail.com ', 1, 'Diterima'),
(28, 'encep.sunandar@gmail.com ', 1, 'Diterima'),
(29, 'meilanitam12@gmail.com ', 1, 'Diterima'),
(30, 'taufiqurahman.fh@gmail.com ', 1, 'Diterima'),
(31, 'dianto.brew09@gmail.com ', 1, 'Diterima'),
(32, 'ggmharis@gmail.com ', 1, 'Diterima'),
(33, 'adellafatinnia2016@gmail.com ', 1, 'Diterima');

-- --------------------------------------------------------

--
-- Table structure for table `tb_survey2`
--

CREATE TABLE `tb_survey2` (
  `no` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jam` varchar(30) NOT NULL,
  `kelas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_survey2`
--

INSERT INTO `tb_survey2` (`no`, `tgl`, `jam`, `kelas`) VALUES
(22, '2021-11-16', '10.11', 'kelas_santuy'),
(23, '2021-11-16', '13.50', 'kelas_serius'),
(27, '2021-11-20', '06.33', 'kelas_CI'),
(28, '2021-11-20', '06.33', 'kelas_serius'),
(29, '2021-11-20', '06.33', 'kelas_santuy'),
(30, '2021-11-23', '09.25', 'kelas_CI'),
(31, '2021-11-23', '09.25', 'kelas_serius'),
(32, '2021-11-23', '09.25', 'kelas_santuy'),
(33, '2021-11-24', '22.24', 'kelas_CI'),
(34, '2021-11-24', '22.24', 'kelas_serius'),
(35, '2021-11-24', '22.24', 'kelas_santuy'),
(36, '2021-11-25', '07.38', 'kelas_santuy'),
(37, '2021-11-25', '07.38', 'kelas_serius'),
(38, '2021-11-25', '07.38', 'kelas_CI'),
(39, '2021-11-26', '13.37', 'kelas_santuy'),
(40, '2021-12-06', '20.32', 'kelas_CI'),
(41, '2021-12-06', '20.32', 'kelas_santuy'),
(42, '2021-12-06', '20.32', 'kelas_serius'),
(43, '2021-12-14', '18.41', 'kelas_serius'),
(44, '2021-12-17', '10.02', 'kelas_serius'),
(45, '2021-12-17', '10.02', 'kelas_santuy'),
(46, '2021-12-17', '10.02', 'kelas_CI'),
(47, '2021-12-21', '07.36', 'kelas_CI'),
(48, '2021-12-23', '10.31', 'kelas_santuy'),
(49, '2021-12-23', '11.20', 'kelas_CI');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_belajar`
--
ALTER TABLE `tb_belajar`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `tb_member`
--
ALTER TABLE `tb_member`
  ADD PRIMARY KEY (`id_member`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `tb_survey2`
--
ALTER TABLE `tb_survey2`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_belajar`
--
ALTER TABLE `tb_belajar`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_member`
--
ALTER TABLE `tb_member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tb_order`
--
ALTER TABLE `tb_order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tb_survey2`
--
ALTER TABLE `tb_survey2`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
