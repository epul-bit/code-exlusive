<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Member extends CI_Controller {
   function __construct(){
		parent::__construct();
		$this->load->model('Mcode');
		if($this->session->userdata('status') != "login"){
			redirect(base_url("home/index"));
		}
	}
	public function beranda()
	{
		$username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
	    $data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['data']   = $this->db->get_where("tb_order",$where);
	    $data['join2']  = $this->Mcode->duatable(); //join table
		$this->load->view('member/home',$data);
	}
	
	public function order()
	{
		$this->load->view('member/order');
	}
	public function order_simpan(){
		$idkelas    = $this->input->post('tkelas');
		$email      = $this->input->post('temail');
		$status     = "Diterima";
//$status     = "Pending";
		$data = array(
			'email'      => $email,
			'id_kelas'   => $idkelas,
			'status'     => $status
			);
		$this->Mcode->morder_simpan($data,'tb_order');
		redirect('member/beranda?pesan=simpan');
	}
    
    public function slide1()
	{
	    $username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
		$data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['join2']  = $this->Mcode->duatable();
	    $kelas="1";
	    $wherekelas = array(
			'email'     => $username,
			'id_kelas'  => $kelas
			);
	    $data['kelas'] = $this->db->get_where("tb_belajar",$wherekelas)->num_rows();
	    $data['r1'] = $this->Mcode->belajar1($wherekelas,'tb_belajar')->result();
		$this->load->view('member/web_gaji/slide1',$data);
	}
	public function slide2()
	{
	    $username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
		$data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['join2']  = $this->Mcode->duatable();
	    $kelas="1";
	    $wherekelas = array(
			'email'     => $username,
			'id_kelas'  => $kelas
			);
	    $data['kelas'] = $this->db->get_where("tb_belajar",$wherekelas)->num_rows();
	    $data['r1'] = $this->Mcode->belajar1($wherekelas,'tb_belajar')->result();
		$this->load->view('member/web_gaji/slide2',$data);
	}
	public function slide3()
	{
	    $username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
		$data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['join2']  = $this->Mcode->duatable();
	    $kelas="1";
	    $wherekelas = array(
			'email'     => $username,
			'id_kelas'  => $kelas
			);
	    $data['kelas'] = $this->db->get_where("tb_belajar",$wherekelas)->num_rows();
	    $data['r1'] = $this->Mcode->belajar1($wherekelas,'tb_belajar')->result();
		$this->load->view('member/web_gaji/slide3',$data);
	}
	public function slide4()
	{
	    $username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
		$data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['join2']  = $this->Mcode->duatable();
	    $kelas="1";
	    $wherekelas = array(
			'email'     => $username,
			'id_kelas'  => $kelas
			);
	    $data['kelas'] = $this->db->get_where("tb_belajar",$wherekelas)->num_rows();
	    $data['r1'] = $this->Mcode->belajar1($wherekelas,'tb_belajar')->result();
		$this->load->view('member/web_gaji/slide4',$data);
	}
	public function slide5()
	{
	    $username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
		$data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['join2']  = $this->Mcode->duatable();
	    $kelas="1";
	    $wherekelas = array(
			'email'     => $username,
			'id_kelas'  => $kelas
			);
	    $data['kelas'] = $this->db->get_where("tb_belajar",$wherekelas)->num_rows();
	    $data['r1'] = $this->Mcode->belajar1($wherekelas,'tb_belajar')->result();
		$this->load->view('member/web_gaji/slide5',$data);
	}
//simpan slide 1
    public function slide1simpan(){
		$kelas      = $this->input->get('kelas');
		$email      = $this->input->get('email');
		$slide1     = "1";
		$kosong     = "0";
		$data = array(
			'id_kelas'  => $kelas,
			'email'     => $email,
			'slide1'    => $slide1,
			'slide2'    => $kosong,
			'slide3'    => $kosong,
			'slide4'    => $kosong,
			'slide5'    => $kosong,
			'selesai'   => $kosong
			);
		$this->Mcode->mdaftar($data,'tb_belajar');
		redirect('member/slide2');
	}
	function slide2editsimpan(){
	    $kelas      = $this->input->get('kelas');
		$email      = $this->input->get('email');
		$slide2     = "1";
		$data = array(
			slide2 => $slide2
		);
		$where = array(
			'id_kelas' => $kelas,
			'email'     => $email
		);
		$this->Mcode->mslideditsimpan($where,$data,'tb_belajar');
	    redirect('member/slide3');
	}
	function slide3editsimpan(){
	    $kelas      = $this->input->get('kelas');
		$email      = $this->input->get('email');
		$slide3     = "1";
		$data = array(
			slide3 => $slide3
		);
		$where = array(
			'id_kelas' => $kelas,
			'email'     => $email
		);
		$this->Mcode->mslideditsimpan($where,$data,'tb_belajar');
	    redirect('member/slide4');
	}
	function slide4editsimpan(){
	    $kelas      = $this->input->get('kelas');
		$email      = $this->input->get('email');
		$slide4     = "1";
		$data = array(
			slide4 => $slide4
		);
		$where = array(
			'id_kelas' => $kelas,
			'email'     => $email
		);
		$this->Mcode->mslideditsimpan($where,$data,'tb_belajar');
	    redirect('member/slide5');
	}
	function slide5editsimpan(){
	    $kelas      = $this->input->get('kelas');
		$email      = $this->input->get('email');
		$slide5     = "1";
		$selesai    = "1";
		$data = array(
			slide5  => $slide5,
			selesai => $selesai
		);
		$where = array(
			'id_kelas' => $kelas,
			'email'     => $email
		);
		$this->Mcode->mslideditsimpan($where,$data,'tb_belajar');
	    redirect('member/slide5');
	}
}
