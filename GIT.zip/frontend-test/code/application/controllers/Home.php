<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {
    function __construct(){
		parent::__construct();
		$this->load->model('Mcode');
	}
	public function index()
	{
		$data['jumlah'] = $this->db->get_where("tb_member")->num_rows();
		$this->load->view('utama',$data);
	}
	public function eror()
	{
		$this->load->view('kosong');
	}
	public function logadm1nn_CE()
	{
		$this->load->view('login_admin');
	}
	function cek_admin(){ //Proses LOGIN
		$username = $this->input->post('tusername');
		$password = $this->input->post('tpassword');
		$where = array(
			'username'      => $username,
		    'password'      => md5($password)
			);
		$cek        = $this->Mcode->cek_login("tb_admin",$where)->num_rows();
		if($cek > 0){
			$data_session = array(
				'nama'      => $username,
				'status'    => "login",
				);
			$this->session->set_userdata($data_session);
			redirect(base_url("admin/beranda"));
		}else{
			redirect(base_url("home/logadmin?no=0&pesan=gagal"));
		}
	}
	public function logmember()
	{
		$this->load->view('login_member');
	}
	public function daftar_simpan(){
		$jam        = $this->input->post('tjam');
		$tgl        = $this->input->post('ttgl');
		$nama       = $this->input->post('tnama');
		$ttl        = $this->input->post('ttl');
		$telp       = $this->input->post('thp');
		$sebagai    = $this->input->post('tsebagai');
		$mail       = $this->input->post('tmail');
		$password   = $this->input->post('tpassword');
		$alamat     = $this->input->post('talamat');
		$data = array(
			'tgl'       => $tgl,
			'jam'       => $jam,
			'nama'      => $nama,
			'telp'      => $telp,
			'tgl_lahir' => $ttl,
			'kategori'  => $sebagai,
			'email'     => $mail,
			'alamat'    => $alamat,
			'password'  => $password
			);
		$where = array(
			'email' => $mail
			);
		$cek   = $this->Mcode->cek_daftar("tb_member",$where)->num_rows();
		if ($cek>0)
		{
		    echo "<script> 
                alert('Gagal daftar, Anda tidak diperkenankan untuk menggunakan email yang sama...');
                document.location.href = 'index';
            </script>";
		}
		else
		{
		    $this->Mcode->mdaftar($data,'tb_member');
		    redirect(base_url("home/logmember?no=0&pesan=daftar"));
		}
	}

    function aksi_login(){ //Proses LOGIN
		$username = $this->input->post('tusername');
		$password = $this->input->post('tpassword');
		$where = array(
			'email'         => $username,
			'password'      => $password
		    //'password'    => md5($password)
			);
		$cek        = $this->Mcode->cek_login("tb_member",$where)->num_rows();
		//$r        = $this->Mcode->cek_login("tb_member",$where);
		$data['r']  = $this->db->get_where("tb_member",$where);
		if($cek > 0){
			$data_session = array(
				'nama'      => $username,
				'status'    => "login",
				'member'    => $r['id_member'] //masih eror 
				);
			$this->session->set_userdata($data_session);
			redirect(base_url("member/beranda"));
		}else{
			redirect(base_url("home/logmember?no=0&pesan=gagal"));
		}
	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('home'));
	}
	
//Survey Kelas
    function survey_edit($id){//untuk tampil ke form
        //$minat=0;
        $data = array(
			'minat' => +1
		);
		$where = array(
			'no' => $id
		);
		$this->Mcode->msurvey_editsimpan($where,$data,'tb_survey');
		redirect('admin/develope');
		//$this->load->view('utama',$data);
	}
	function kelas_santuy(){
	    $kelas = "kelas_santuy";
	    date_default_timezone_set('Asia/jakarta');
        $jam =date ('H.i');
        $tgl =date ('Y-m-d');
        	$data = array(
			'tgl'   => $tgl,
			'jam'   => $jam,
			'kelas' => $kelas
			);
		$this->Mcode->msurvey_simpan($data,'tb_survey2');
		redirect('admin/develope');
	}
	function kelas_serius(){
	    $kelas = "kelas_serius";
	    date_default_timezone_set('Asia/jakarta');
        $jam =date ('H.i');
        $tgl =date ('Y-m-d');
        	$data = array(
			'tgl'   => $tgl,
			'jam'   => $jam,
			'kelas' => $kelas
			);
		$this->Mcode->msurvey_simpan($data,'tb_survey2');
		redirect('admin/develope');
	}
	function kelas_jangar(){
	    $kelas = "kelas_CI";
	    date_default_timezone_set('Asia/jakarta');
        $jam =date ('H.i');
        $tgl =date ('Y-m-d');
        	$data = array(
			'tgl'   => $tgl,
			'jam'   => $jam,
			'kelas' => $kelas
			);
		$this->Mcode->msurvey_simpan($data,'tb_survey2');
		redirect('admin/develope');
	}
}
