<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
   function __construct(){
		parent::__construct();
		$this->load->model('Mcode');
		if($this->session->userdata('status') != "login"){
			redirect(base_url("home/index"));
		}
	}
	public function beranda()
	{
		$username=$this->session->userdata("nama");
		$status="Diterima";
	    $where = array(
			'email'     => $username,
			'status'    => $status
			);
	    $data['jumlah'] = $this->db->get_where("tb_order",$where)->num_rows();
	    $data['data']   = $this->db->get_where("tb_order",$where);
	    $data['join2']  = $this->Mcode->duatable(); //join table
		$this->load->view('admin/home',$data);
	}
	public function member()
	{
		$x['datamember']=$this->Mcode->show_member();
		$this->load->view('admin/member',$x);
	}
	public function belajar()
	{
		$x['databelajar']=$this->Mcode->show_belajar();
		$this->load->view('admin/belajar',$x);
	}
}
