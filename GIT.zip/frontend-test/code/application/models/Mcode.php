<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mcode extends CI_Model{//Hati-hati harus CI_MODEL karena akan berefek pada Session
    public function mdaftar($data,$table){
		$this->db->insert($table,$data);
	}
	function cek_daftar($table,$where){		
		return $this->db->get_where($table,$where);
	}
	function cek_login($table,$where){		
		return $this->db->get_where($table,$where);
	}
	public function morder_simpan($data,$table){
		$this->db->insert($table,$data);
	}
    public function duatable() { //join
//HARUS DIEVALUASI KEMBALI
        $username="7";
        $this->db->select('*');
        $this->db->from('tb_order');
        $this->db->join('tb_kelas','tb_order.id_kelas=tb_kelas.id_kelas');
        $this->db->where('id_order='.$username);
        $query = $this->db->get();
        return $query->result();
    }
    function belajar1($where,$table){		
		return $this->db->get_where($table,$where);
	}
	function mslideditsimpan($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	public function show_member(){
		$hasil=$this->db->query("SELECT * FROM tb_member ORDER BY id_member DESC");
		return $hasil;
	}
	public function show_belajar(){
		$hasil=$this->db->query("SELECT * FROM tb_belajar ORDER BY id_kelas DESC");
		return $hasil;
	}
//UJICOBA
	
	public function msurvey_editsimpan($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function msurvey_simpan($data,$table){
		$this->db->insert($table,$data);
	}
}