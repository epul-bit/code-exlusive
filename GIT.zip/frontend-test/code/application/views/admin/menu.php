<ul id="sidebarnav" class="p-t-30">
    <li class="sidebar-item"> 
    	<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php base_url() ?>/admin/beranda" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Beranda</span>
	    </a>
	</li>
	
	<li class="sidebar-item"> 
    	<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php base_url() ?>/admin/member" aria-expanded="false"><i class="mdi mdi-grid"></i><span class="hide-menu">Data Member</span>
	    </a>
	</li>
	<li class="sidebar-item"> 
    	<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php base_url() ?>/admin/belajar" aria-expanded="false"><i class="mdi mdi-monitor"></i><span class="hide-menu">Pengerjaan</span>
	    </a>
	</li>
	
	<li class="sidebar-item"> 
		<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php  echo base_url()?>/home/logout" aria-expanded="false">
			<i class="fa fa-power-off "></i><span class="hide-menu">Logout</span>
		</a>
	</li>
</ul>