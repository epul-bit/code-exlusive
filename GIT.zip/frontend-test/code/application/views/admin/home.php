<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>/assets/img/favicon.png">
    <title>Selamat Datang Di Website Kami</title>
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/multicheck.css">
    <link href="<?php echo base_url() ?>/assets/member/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/member/dist/css/style.min.css" rel="stylesheet">
</head>
<body>
    <div id="main-wrapper">
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                     <a class="navbar-brand" href="index.html">
                        <!-- Logo icon -->
                        <b class="logo-icon p-l-10">
                            <img src="<?php echo base_url() ?>/assets/img/logo.png" alt="homepage" class="light-logo" width="45px">
                        </b>
                        <span class="logo-text">
                             Code Exclusive
                        </span>
                    </a>
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                    </ul>
                </div>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                 <?php include "menu.php"; ?>
                </nav>
            </div>
        </aside>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Halaman Beranda</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                             
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                              <h2>Hai, 
                              <?php echo $this->session->userdata('nama') ?>!
                              <?php //echo $this->session->userdata('member') ?>
                              </h2>
                              Selamat Datang Di Halaman Member Code Exclusive.
                            </div> 
                        </div>
                   </div>
                </div>
            </div>
            <footer class="footer text-center">
                <?php include "footer.php" ?>
            </footer>
        </div>
    </div>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/sparkline/sparkline.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/waves.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/sidebarmenu.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/custom.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/jquery.multicheck.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/DataTables/datatables.min.js"></script>
    <script>
        $('#zero_config').DataTable();
    </script>
</body>
</html>