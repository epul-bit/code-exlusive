<ul id="sidebarnav" class="p-t-30">
    <li class="sidebar-item"> 
    	<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php base_url() ?>/member/beranda" aria-expanded="false"><i class="mdi mdi-home"></i><span class="hide-menu">Beranda</span>
	    </a>
	</li>
        
    <?php
    if ($jumlah>=1)
    {
          foreach ($join2 as $row) {
    ?>
	<li class="sidebar-item"> 
		<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php base_url() ?>/member/slide1" aria-expanded="false"><i class="mdi mdi-monitor"></i><span class="hide-menu">
		    <?php echo $row->kelas;?>
		</span>
		</a>
	</li>
	<?php
          }
    }
	?>
	
	<li class="sidebar-item"> 
		<a class="sidebar-link waves-effect waves-dark sidebar-link" href="<?php  echo base_url()?>/home/logout" aria-expanded="false">
			<i class="fa fa-power-off "></i><span class="hide-menu">Logout</span>
		</a>
	</li>
</ul>