 <script src="<?php echo base_url() ?>/assets/member/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/sparkline/sparkline.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/waves.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/sidebarmenu.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/dist/js/custom.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/jquery.multicheck.js"></script>
    <script src="<?php echo base_url() ?>/assets/member/assets/extra-libs/DataTables/datatables.min.js"></script>
    <script>
        $('#zero_config').DataTable();
    </script>