 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>/assets/img/favicon.png">
    <title>Selamat Datang Di Website Kami</title>
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/assets/member/assets/extra-libs/multicheck/multicheck.css">
    <link href="<?php echo base_url() ?>/assets/member/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/member/dist/css/style.min.css" rel="stylesheet">