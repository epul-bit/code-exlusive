<div style="overflow:auto">
<?php
    if ($kelas>=1)
    {
        foreach($r1 as $u)
		{
		    $slide1= $u->slide1;
		    $slide2= $u->slide2;
		    $slide3= $u->slide3;
		    $slide4= $u->slide4;
		    $slide5= $u->slide5;
    ?>  
        <table class="table table-striped table-bordered">
        <tr>
            <td>
            <a href="<?php echo base_url() ?>member/slide1">
            <button type="button" class="btn btn-success btn-block">
                Analisis Studi Kasus 
            </button>
            </td>
            <td>
            <?php 
            if ($slide1=="1")
		    {
		    ?>
		        <img src="<?php echo base_url ('assets/img/ceklis.png') ?>" width="25px">
		    <?php
		    }
            ?>
            </td>
            </tr>
        
        <tr>
            <td>
            <?php 
            if ($slide1=="1")
		    {
            ?>
                <a href="<?php echo base_url() ?>member/slide2">
                <button type="button" class="btn btn-danger btn-block">
                UML
                </button>
                </a>
            <?php
		    }
		    else
		    {
		    ?>
                <button type="button" class="btn btn-secondary btn-block" disabled>
                UML
                </button>
            <?php   
		    }
            ?>
            </td>
            <td>
            <?php 
            if ($slide2=="1")
		    {
		    ?>
		        <img src="<?php echo base_url ('assets/img/ceklis.png') ?>" width="25px">
		    <?php
		    }
            ?>
            </td>
        </tr>
        <tr>
            <td>
            <?php 
            if ($slide2=="1")
		    {
            ?>
                <a href="<?php echo base_url() ?>member/slide3">
                <button type="button" class="btn btn-success btn-block">
                Entity Relationship Diagram
                </button>
                </a>
            <?php
		    }
		    else
		    {
		    ?>
                <button type="button" class="btn btn-secondary btn-block" disabled>
                Entity Relationship Diagram
                </button>
		    <?php   
		    }
            ?>
            </td>
            <td>
            <?php 
            if ($slide3=="1")
		    {
		    ?>
		        <img src="<?php echo base_url ('assets/img/ceklis.png') ?>" width="25px">
		    <?php
		    }
		    ?>
            </td>
        </tr>
        <tr>
            <td>
            <?php 
            if ($slide3=="1")
		    {
            ?>    
                <a href="<?php echo base_url() ?>member/slide4">
                <button type="button" class="btn btn-danger btn-block">
                DBMS (MYSQL)
                </button>
                </a>
            <?php
		    }
		    else
		    {
		    ?>
                <button type="button" class="btn btn-secondary btn-block" disabled>
                DBMS (MYSQL)
                </button>
            <?php 
		    }
            ?>
            </td>
            <td>
            <?php 
            if ($slide4=="1")
		    {
		    ?>
		        <img src="<?php echo base_url ('assets/img/ceklis.png') ?>" width="25px">
		    <?php
		    }
		    ?>
            </td>
        </tr>
        <tr>
            <td>
            <?php 
            if ($slide4=="1")
		    {
            ?>
                <a href="<?php echo base_url() ?>member/slide5">
                <button type="button" class="btn btn-success btn-block">
                Implementasi Website
                </button>
                </a>
            <?php
		    }
		    else
		    {
		    ?>
    		    <button type="button" class="btn btn-secondary btn-block" disabled>
                Implementasi Website
                </button>
            <?php
		    }
            ?>
            </td>
            <td>
            <?php 
            if ($slide5=="1")
		    {
		    ?>
		        <img src="<?php echo base_url ('assets/img/ceklis.png') ?>" width="25px">
		    <?php
		    }
		    ?>
            </td>
        </tr>
    </table>
    <?php 
          }
    }
    else if ($kelas<1)
    {
    ?>  
        <table class="table table-striped table-bordered">
        <tr>
            <td>
            <a href="<?php echo base_url() ?>member/slide1">
            <button type="button" class="btn btn-success btn-block">
                Analisis Studi Kasus 
            </button>
            </td>
            <td>
            </td>
            </tr>
        <tr>
            <td>
                <button type="button" class="btn btn-secondary btn-block" disabled>
                UML
                </button>
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td>
                <button type="button" class="btn btn-secondary btn-block" disabled>
                Entity Relationship Diagram
                </button>
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td>
            <button type="button" class="btn btn-secondary btn-block" disabled>
                DBMS (MYSQL)
                </button>
            </td>
            <td>
            </td>
        </tr>
        <tr>
            <td>
    		    <button type="button" class="btn btn-secondary btn-block" disabled>
                Implementasi Website
                </button>
            </td>
            <td>
            </td>
        </tr>
    </table>
    <?php   
    }
    ?>
</div>                              