<html>
<head>
    <?php $this->load->view("member/web_gaji/pendukung/header.php");?> 
</head>
<body>
    <div id="main-wrapper">
    <?php $this->load->view("member/web_gaji/pendukung/judul.php");?> 
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                   <?php $this->load->view("member/menu.php");?> 
                </nav>
            </div>
        </aside>
        
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Sistem slip gaji online berbasis website</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                             
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                $this->load->view("member/web_gaji/poin.php");
                                ?> 
                            </div> 
                        </div>
                   </div>
                  <div class="col-8">
                        <div class="card">
                            <div class="card-body">
                              <b>Unified Modeling Language (UML)</b>
                                <hr>
                              <iframe width="100%" height="373" src="https://www.youtube.com/embed/xSbE8CxIgic" title="YouTube video player" frameborder="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              <br><br>
                              <p align="right">
                                <a href="<?php echo base_url() ?>member/slide2editsimpan?kelas=1&email=<?php echo $this->session->userdata('nama') ?>">
                                  <input type="button" value="Next" class="btn btn-primary">
                              </a>
                              </p>
                            </div> 
                        </div>
                   </div>
                </div>
            </div>
            <footer class="footer text-center">
               <?php $this->load->view("member/footer.php");?>
            </footer>
        </div>
    </div>
   <?php $this->load->view("member/web_gaji/pendukung/modul.php");?> 
</body>
</html>