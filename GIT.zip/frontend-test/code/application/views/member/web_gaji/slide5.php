<html>
<head>
    <?php $this->load->view("member/web_gaji/pendukung/header.php");?> 
</head>
<body>
    <div id="main-wrapper">
    <?php $this->load->view("member/web_gaji/pendukung/judul.php");?> 
        
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                   <?php $this->load->view("member/menu.php");?> 
                </nav>
            </div>
        </aside>
        
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Sistem slip gaji online berbasis website</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                             
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4">
                        <div class="card">
                            <div class="card-body">
                                <?php 
                                $this->load->view("member/web_gaji/poin.php");
                                ?> 
                            </div> 
                        </div>
                   </div>
                  <div class="col-8">
                        <div class="card">
                            <div class="card-body">
                              <b>Implementasi Website</b>
                                <hr>
                              <br><br>
                              <p align="right">
<?php
foreach($r1 as $u)
    {
        $selesai= $u->selesai;
        if ($selesai=="0")//belum ada data tersimpan
        {
?>
        <a href="<?php echo base_url() ?>member/slide5editsimpan?kelas=1&email=<?php echo $this->session->userdata('nama') ?>">
            <input type="button" value="Selesai" class="btn btn-primary">
        </a>
<?php
        }
        else if ($selesai=="1")
        {
?>
        <a href="#">
            <input type="button" value="Isi Kuesioner" class="btn btn-success">
        </a>                       
<?php
        }
    }
?>
                              </p>
                            </div> 
                        </div>
                   </div>
                </div>
            </div>
            <footer class="footer text-center">
               <?php $this->load->view("member/footer.php");?>
            </footer>
        </div>
    </div>
   <?php $this->load->view("member/web_gaji/pendukung/modul.php");?> 
</body>
</html>