  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
       <a href="<?php echo base_url() ?>home" ><img src="<?php echo base_url('assets/img/logo.png')?>" alt="" class="img-fluid"></a>
      <h1 class="logo mr-auto"><a href="index.html"> Code-Exclusive</a></h1>
      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="<?php echo base_url() ?>home">Home</a></li>
          <li><a href="#about">Tentang Kami</a></li>
          <li><a href="#portfolio">Product</a></li>
          <li><a href="#pricing">Course</a></li>
          <li><a href="#kursus">Analisis & Rancangan</a></li>
          <!--
          <li class="drop-down"><a href="">Respon</a>
            <ul>
              <li><a href="#">Benefit</a></li>
              <li><a href="#">Testimoni</a></li>
            </ul>
          </li>
          -->
          <li><a href="#daftar">DAFTAR</a></li>
        </ul>
      </nav><!-- .nav-menu -->
      <a href="<?php echo site_url ('home/logmember?no=0');?>" class="get-started-btn">LOGIN</a>
    </div>
  </header><!-- End Header -->