  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">
      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>
      <div class="carousel-inner" role="listbox">
        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(<?php echo base_url('assets/img/slide/slide-1.jpg')?>)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Hai, <span>Exclusive Coder</span></h2>
              <p class="animate__animated animate__fadeInUp">
              <b>Fokus</b> utama kami yaitu membantu anda mempelajari dan <br>menguasai website dengan mudah. <b>Kami</b> menyediakan produk untuk keperluan organisasi anda. </p>
              <a href="#daftar" class="btn-get-started animate__animated animate__fadeInUp scrollto">Join Member</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(<?php echo base_url('assets/img/slide/slide-2.jpg')?>)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">Melayani Pembuatan Sistem </h2>
              <p class="animate__animated animate__fadeInUp">Kami membuka layanan jasa pembuatan sistem berbasis website.</p>
              <a href="https://api.whatsapp.com/send?phone=6285280268295&text=Assalamualaikum%20Saya%20ingin konsultasi%20terkait%20Projek%20saya%20/-%20CODE EXCLUSIEVE." class="btn-get-started animate__animated animate__fadeInUp scrollto" target="_blank">Konsultasi Sekarang</a>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>

    </div>
  </section>

  <main id="main">
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Tentang Kami</p>
        </div>
      </div>
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row no-gutters">
          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-simple-smile"></i>
              <span data-toggle="counter-up">
                  <?php echo $jumlah ?>
              </span>
              <p><strong>Member</strong> Code-Exclusive</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">32</span>
              <p><strong>Projek</strong> Code-Exclusive</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-live-support"></i>
              <span data-toggle="counter-up">7</span>
              <p><strong>Rekanan</strong> Code-Exclusive</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <i class="icofont-users-alt-5"></i>
              <span data-toggle="counter-up">3</span>
              <p><strong>Team</strong> Code-Exclusive</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->
    <section id="why-us" class="why-us section-bg">
      <div class="container-fluid" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-5 align-items-stretch video-box" style='background-image: url("<?php echo base_url('assets/img/why-us.jpg')?>");' data-aos="zoom-in" data-aos-delay="100">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>
          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch">
            <div class="content">
              <h3>We Are <strong>Code Exclusive</strong></h3>
              <h5>
                Kami melayani :
              </h5>
            </div>

            <div class="accordion-list">
              <ul>
                <li>
                  <a data-toggle="collapse" class="collapse" href="#accordion-list-1"><span>01</span> Pembuatan Sistem Berbasis Website <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse" data-parent=".accordion-list">
                    <p>
                      - Sistem Pengelolaan Data Karyawan (HRD/SDM) <br>
                      - Tanda Tangan Digital <br>
                      - E-Sertifikat Berbasis Website <br>
                      - Website Company Profil <br>
                      - Sistem Pengelolaan Data Perumahan Syariah/konvesional <br>
                      - Rekam Medis Elektronik (RAJAL) + TTD Digital <br>
                      - Rekam Medis Elektronik (RANAP) + TTD Digital<br>
                      - Rekam Medis Elektronik (IGD) + TTD Digital <br>
                      - Logbook Perawat Online <br>
                      - Sistem Jadwal Dinas Online <br>
                      - Absen Online via Smartphone <br>
                      - Absen via QRcode/Barcode <br>
                      - Sistem Pengaduan Online <br>
                      - Daftar Online Pasien <br>
                      - Sistem Pengaduan pasien online <br>
                      - Sistem Slip Gaji Karyawan Online <br>
                      - Sistem Pengelolaan Berkas <br>
                      - Sistem E-Recruitment <br>
                      - Sistem SIMRS FULL Berbasis website, dll <br>
                      - dan lain sebagainya (Sesuai Permintaan)
                    </p>
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#accordion-list-2" class="collapsed"><span>02</span> Website dasar dan menengah <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-parent=".accordion-list">
                    <p>
                      - Web Dasar<br>
                      - Web Menengah <br>
                      - Framework
                    </p>
                  </div>
                </li>

                <li>
                  <a data-toggle="collapse" href="#accordion-list-3" class="collapsed"><span>03</span> analisis & Rancangan <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-parent=".accordion-list">
                    <p>
                        - Sistem Slip gaji Online berbasis website<br>
                    <!--
                      - Website Perumahan Syariah (Back end)<br>
                      - Website Company Profile (Front end & Back End) <br>
                      - Webservice (Bridging BPJS - JKN MOBILE)
                      -->
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Produk dan Layanan Kami</p>
        </div>

        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">Medis</li>
              <li data-filter=".filter-card">HRD</li>
              <li data-filter=".filter-web">Company Profile</li>
              <li data-filter=".filter-web">Umum</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
           <iframe width="360" height="240" src="https://www.youtube.com/embed/-zAUdL_mX6s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <div class="portfolio-info">
              <h4>Tanda tangan digital </h4>
              <p>Ttd tanpa db, sourcode terlampir</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-1.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="App 1"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
           <iframe width="360" height="240" src="https://www.youtube.com/embed/_wT4CkXv_ak" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <div class="portfolio-info">
              <h4>Sistem E-Sertifikat</h4>
              <p>Sertifikat Elektronik Berbasis Website</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-3.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="App 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <iframe width="360" height="240" src="https://www.youtube.com/embed/t8fCCOJp-eE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <div class="portfolio-info">
              <h4>Mengambil data header dari postman</h4>
              <p>Tutorial dasar web service</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-2.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="Web 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
<!--
          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="<?php echo base_url('assets/img/portfolio/portfolio-4.jpg')?>" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Card 2</h4>
              <p>Card</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-4.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="Card 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="<?php echo base_url('assets/img/portfolio/portfolio-5.jpg')?>" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>Web 2</h4>
              <p>Web</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-5.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="Web 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="<?php echo base_url('assets/img/portfolio/portfolio-6.jpg')?>" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>App 3</h4>
              <p>App</p>
              <a href="<?php echo base_url('assets/img/portfolio/portfolio-6.jpg')?>" data-gall="portfolioGallery" class="venobox preview-link" title="App 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
-->
        

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="text-center">
          <h3>Hubungi Kami</h3>
          <p>Konsultasikan ide dan rencana digital anda bersama kami.</p>
          <a class="cta-btn" href="https://api.whatsapp.com/send?phone=6285280268295&text=Assalamualaikum%20Saya%20ingin konsulasti%20terkait%20CODE EXCLUSIEVE." class="btn-get-started animate__animated animate__fadeInUp scrollto" target="_blank">Konsultasi Sekarang</a>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Testimoni</p>
        </div>

        <div class="owl-carousel testimonials-carousel">

          <div class="testimonial-wrap">
            <div class="testimonial-item">
              <img src="<?php echo base_url('assets/img/testimonials/testimonials-1.jpg')?>" class="testimonial-img" alt="">
              <h3>Saul Goodman</h3>
              <h4>Ceo &amp; Founder</h4>
              <p>
                <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                <i class="bx bxs-quote-alt-right quote-icon-right"></i>
              </p>
            </div>
          </div>

          <div class="testimonial-wrap">
            <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
              <h3>Sara Wilsson</h3>
              <h4>Designer</h4>
              <p>
                <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                <i class="bx bxs-quote-alt-right quote-icon-right"></i>
              </p>
            </div>
          </div>

          <div class="testimonial-wrap">
            <div class="testimonial-item">
              <img src="<?php echo base_url('assets/img/testimonials/testimonials-3.jpg')?>" class="testimonial-img" alt="">
              <h3>Jena Karlis</h3>
              <h4>Store Owner</h4>
              <p>
                <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                <i class="bx bxs-quote-alt-right quote-icon-right"></i>
              </p>
            </div>
          </div>

          <div class="testimonial-wrap">
            <div class="testimonial-item">
              <img src="<?php echo base_url('assets/img/testimonials/testimonials-4.jpg')?>" class="testimonial-img" alt="">
              <h3>Matt Brandon</h3>
              <h4>Freelancer</h4>
              <p>
                <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                <i class="bx bxs-quote-alt-right quote-icon-right"></i>
              </p>
            </div>
          </div>

          <div class="testimonial-wrap">
            <div class="testimonial-item">
              <img src="<?php echo base_url('assets/img/testimonials/testimonials-5.jpg')?>" class="testimonial-img" alt="">
              <h3>John Larson</h3>
              <h4>Entrepreneur</h4>
              <p>
                <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
                <i class="bx bxs-quote-alt-right quote-icon-right"></i>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Team Kami</p>
        </div>

        <div class="row">

          <div class="col-xl-3 col-lg-4 col-md-6">
            <div class="member" data-aos="zoom-in" data-aos-delay="100">
              <img src="<?php echo base_url('assets/img/team/team-1.jpg')?>" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                <div style="color: white; font-size: 14px"><b>Ramdhan Saepul R, M.Kom</b></div>
                  <span>Founder & CEO Code Exclusive</span>
                </div>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6" data-wow-delay="0.1s">
            <div class="member" data-aos="zoom-in" data-aos-delay="200">
              <img src="<?php echo base_url('assets/img/team/team-2.jpg')?>" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>Riswanda Kuncahyo</h4>
                  <span>Front-End Programmer</span>
                </div>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <!--
          <div class="col-xl-3 col-lg-4 col-md-6" data-wow-delay="0.2s">
            <div class="member" data-aos="zoom-in" data-aos-delay="300">
              <img src="<?php //echo base_url('assets/img/team/team-3.jpg')?>" class="img-fluid" alt="">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>William Anderson</h4>
                  <span>Back-End Programmer</span>
                </div>
                <div class="social">
                  <a href=""><i class="icofont-twitter"></i></a>
                  <a href=""><i class="icofont-facebook"></i></a>
                  <a href=""><i class="icofont-instagram"></i></a>
                  <a href=""><i class="icofont-linkedin"></i></a>
                </div>
              </div>
            </div>
            -->
          </div>
        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Kursus Exclusive</p>
        </div>

        <div class="row align-items-center">
          <div class="col-lg-4">
            <div class="box" data-aos="zoom-in" data-aos-delay="100">
            <span>Kelas</span>
              <h3>Santuy</h3>
              <h4>Rp.0,-</h4>
              <ul>
                <li><i class="bx bx-check"></i> Dasar HTML</li>
                <li><i class="bx bx-check"></i> Konfigurasi tabel</li>
                <li><i class="bx bx-check"></i> Dasar PHP</li>
                <li><i class="bx bx-check"></i> Variabel</li>
                <!--<li class="na"><i class="bx bx-x"></i> <span>Variabel</span></li>-->
              </ul>
              <!--
<a href="<?php echo site_url()?>home/survey_edit/1" class="get-started-btn">Get Started</a>
-->
<a href="<?php echo site_url()?>home/kelas_santuy" class="get-started-btn">Get Started</a>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="box featured" data-aos="zoom-in" data-aos-delay="100">
              <span>Kelas</span>
              <h3>Serius</h3>
              <h4>Rp. 50.000<span><strike>Rp. 75.000</strike></span></h4>
              <ul>
                <li><i class="bx bx-check"></i> FORM</li>
                <li><i class="bx bx-check"></i> JQUERY</li>
                <li><i class="bx bx-check"></i> JAVASCRIPT</li>
                <li><i class="bx bx-check"></i> TEMPLATE</li>
              </ul>
              <a href="<?php echo site_url()?>home/kelas_serius" class="get-started-btn">Get Started</a>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="box" data-aos="zoom-in" data-aos-delay="100">
              <span>Kelas</span>
              <h3>Jangar</h3>
              <h4>Rp.75.000<span><strike>Rp. 100.000</strike></span></h4>
              <ul>
                <li><i class="bx bx-check"></i> CODE IGNITER</li>
                <li><i class="bx bx-check"></i> Dasar CI</li>
                <li><i class="bx bx-check"></i> Konversi Template ke CI</li>
                <li><i class="bx bx-check"></i> Partial Template CI</li>
                <li><i class="bx bx-check"></i> CRUD CI</li>
              </ul>
              <a href="<?php echo site_url()?>home/kelas_jangar" class="get-started-btn">Get Started</a>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Pricing Section -->


    <section id="kursus" class="pricing">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Membuat Website Perusahaan</p>
        </div>

        <div class="row align-items-center">
          
          <div class="col-lg-4">
            <div class="box featured" data-aos="zoom-in" data-aos-delay="100">
              <span>Full Step by Step</span>
              <h3>Website Slip Gaji</h3>
              <h4>Rp. 0<span><strike>Rp. 300.000</strike></span></h4>
              <ul>
                <li><i class="bx bx-check"></i> analisis Studi Kasus</li>
                <li><i class="bx bx-check"></i> Diagram UML</li>
                <li><i class="bx bx-check"></i> Diagram ERD</li>
                <li><i class="bx bx-check"></i> analisis DBMS</li>
                <li><i class="bx bx-check"></i> Pembagian Hak Akses</li>
                <li><i class="bx bx-check"></i> Login</li>
                <li><i class="bx bx-check"></i> Implementasi Website</li>
                <li><i class="bx bx-check"></i> Cetak Slip gaji</li>
              </ul>
              <a href="<?php echo base_url() ?>home/logmember?no=1&pesan=order" class="get-started-btn">Get Started</a>
            </div>
          </div>
          <!--
          <div class="col-lg-4">
            <div class="box featured" data-aos="zoom-in" data-aos-delay="100">
              <span>Full Step by Step</span>
              <h3>Website Perumahan</h3>
              <h4>Rp. 400.000<span><strike>Rp. 750.000</strike></span></h4>
              <ul>
                <li><i class="bx bx-check"></i> analisis Studi Kasus</li>
                <li><i class="bx bx-check"></i> Normalisasi</li>
                <li><i class="bx bx-check"></i> Tabel & Database</li>
                <li><i class="bx bx-check"></i> Login</li>
                <li><i class="bx bx-check"></i> Back End Master</li>
                <li><i class="bx bx-check"></i> Back End Transaksi</li>
                <li><i class="bx bx-check"></i> Konversi Nominal Nilai uang</li>
                <li><i class="bx bx-check"></i> Notifikasi WhatsApp Blast</li>
                <li><i class="bx bx-check"></i> Laporan Bulanan</li>
                <li><i class="bx bx-check"></i> Laporan Perorangan</li>
              </ul>
              <a href="#" class="get-started-btn">Get Started</a>
            </div>
          </div>
          -->
        </div>
      </div>
    </section><!-- End Pricing Section -->
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Kontak Kami</p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="row">
              <div class="col-md-12">
                <div class="info-box">
                  <i class="bx bx-map"></i>
                  <h3>Alamat</h3>
                  <p>Perum Alam Layung Indah blok O12 Jl. Cikukulu Cisande Kab. Sukabumi</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-envelope"></i>
                  <h3>Email</h3>
                  <p>exclusivecode0@gmail.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box mt-4">
                  <i class="bx bx-phone-call"></i>
                  <h3>Telp/WA</h3>
                  <p>0852 8026 8295</p>
                </div>
              </div>
            </div>

          </div>

          <div class="col-lg-6">
            <img src="<?php echo base_url('assets/img/kontak.png')?>" width="100%">
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
<!--Daftar-->
<!-- ======= Contact Section ======= -->
    <section id="daftar" class="contact section-bg">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>DAFTAR MEMBER</p>
        </div>

        <div class="row">
          <div class="col-lg-6">
            <div class="row">
              <img src="<?php echo base_url('assets/img/ce_daftar.png')?>" width="100%">
            </div>
          </div>

          <div class="col-lg-6">
            <form action="<?php echo site_url(); ?>home/daftar_simpan" method="POST">
<?php date_default_timezone_set('Asia/jakarta'); ?>	    
<input type="hidden" value="<?php echo date ('Y-m-d') ?>" name="ttgl">
<input type="hidden" value="<?php echo date ('H:i') ?>" name="tjam">    
              <div class="form-group">
                <input type="text" class="form-control" name="tnama" placeholder="Nama Lengkap" required>
                <div class="validate"></div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="thp" class="form-control" placeholder="Nomor Telp/WA" required>
                </div>
                <div class="col form-group">
                  <input type="text" name="ttl" class="form-control" placeholder="tanggal lahir : dd/mm/yyyy" required>
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                 <select name="tsebagai" class="form-control">
                   <option> - Daftar Sebagai - </option>
                   <option>Mahasiswa</option>
                   <option>Dosen</option>
                   <option>Siswa</option>
                   <option>Guru</option>
                   <option>Umum</option>
                 </select>
                </div>
              </div>
               <div class="form-row">
                <div class="col form-group">
                    <textarea class="form-control" name="talamat" placeholder="Alamat Lengkap" required></textarea>
                </div>
              </div>
              <div class="form-row">
                <div class="col form-group">
                  <input type="text" name="tmail" class="form-control" placeholder="E-mail" required>
                </div>
                <div class="col form-group">
                  <input type="password" name="tpassword" class="form-control" placeholder="Password" required>
                </div>
              </div>
              <div class="text-center">
                  <input  type="submit" value="Daftar" class="btn btn-success">
            </form>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->    
  </main><!-- End #main -->
  