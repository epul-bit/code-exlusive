<html>
<head>
    <?php $this->load->view("sub/system/header.php");?>
</head>
<body bgcolor="#CCFF99" class="homepage">
  <?php $this->load->view("sub/system/menu.php");?> 
   <!-- ======= Hero Section ======= -->

  <main id="main">
    <section id="about" class="about">
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Code-Exclusive</h2>
          <p>Error 404 - Not Found</p>
        </div>
        <div class='alert alert-danger ' align='center'>
		<b>Mohon maaf, halaman ini sedang dalam pengembangan...</a>
		</div>
      </div>
    </section><!-- End Portfolio Section -->
  </main><!-- End #main -->
  
  <?php $this->load->view("sub/system/footer.php"); ?>       
</body>
</html>