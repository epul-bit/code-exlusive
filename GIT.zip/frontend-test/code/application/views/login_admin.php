<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Code Exclusive</title>
    <link href="<?php echo base_url('assets/img/favicon.png')?>" rel="icon">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css_login/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>/assets/css_login/dist/css/AdminLTE.min.css">
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
   <?php 
  if(isset($_GET['pesan'])){
    if($_GET['pesan'] == "gagal"){
       echo "<div class='alert alert-danger alert-dismissable' align='center'>";
      echo "Login gagal! username dan password salah!";
       echo "</div>";
    }else if($_GET['pesan'] == "logout"){
      echo "<div class='alert alert-info alert-dismissable' align='center'>";
      echo "Anda telah berhasil logout";
      echo "</div>";
    }else if($_GET['pesan'] == "belum_login"){
      echo "<div class='alert alert-danger alert-dismissable' align='center'>";
      echo "Anda harus login untuk mengakses halaman admin";
      echo "</div>";
    }
  }
  ?>
      <div class="login-box-body">
        <p class="login-box-msg"><img src="<?php echo base_url() ?>/assets/img/ce.png" width="150px"></p>
        <form action="<?php echo base_url() ?>home/cek_admin" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="E-mail" name="tusername" required autofocus>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>


          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="tpassword" required>
      
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>          </div>

          <div class="form-group has-feedback">
                <button type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
          </div>

           <div class="form-group has-feedback">
                 <a href="<?php echo base_url() ?>/home"><button type="button" class="btn btn-danger btn-block btn-flat">Batal </button></a>
          </div>
          <div class="row">
            <div class="col-xs-4">
            </div>
            <!-- /.col -->
          </div>
        </form>
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <script src="<?php echo base_url() ?>/assets/css_login/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/css_login/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/css_login/plugins/iCheck/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
  </body>
</html>
