<html>
<head>
    <?php $this->load->view("sub/system/header.php");?>
</head>
<body bgcolor="#CCFF99" class="homepage">
  <?php $this->load->view("sub/system/menu.php");?> 
  <?php $this->load->view("sub/system/konten.php");?>    
  <?php $this->load->view("sub/system/footer.php"); ?>       
</body>
</html>